
package com.mycompany.campeonato;


public class Jugador {
    private String nombre;


    public Jugador(String nombre) {

        this.nombre = nombre;

    }


    public String getNombre() {

        return nombre;

    }
}
